from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
import pandas as pd
import csv
import base64
import hashlib
import re
import os

app = Flask(__name__)
app.secret_key = 'secret_key'

USERS_CSV = 'users.csv'
LAWSET_CSV = 'set.csv'

# Hash password function
def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

# Save user to CSV file with encrypted password
def save_user(username, password, first_name, last_name, mobile, address, dob):
    encoded_password = base64.b64encode(hash_password(password).encode('utf-8')).decode('utf-8')
    with open(USERS_CSV, mode='a', newline='') as csvfile:
        fieldnames = ['username', 'password', 'first_name', 'last_name', 'mobile', 'address', 'dob']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({'username': username, 'password': encoded_password,
                         'first_name': first_name, 'last_name': last_name,
                         'mobile': mobile, 'address': address, 'dob': dob})

# Verify password function
def verify_password(username, password):
    user = get_user(username)
    if user:
        encoded_password = base64.b64encode(hash_password(password).encode('utf-8')).decode('utf-8')
        return user['password'] == encoded_password
    return False

# Get user from CSV file
def get_user(username):
    users_df = pd.read_csv(USERS_CSV)
    for index, row in users_df.iterrows():
        if row['username'] == username:
            return row.to_dict()
    return None

# Load the LawSet dataset
laws_dataset = pd.read_csv(LAWSET_CSV)

# Routes

@app.route('/')
def index():
    # Redirect to the login page
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if verify_password(username, password):
            flash('Login successful!', 'success')
            return redirect(url_for('home'))  # Redirect to the home page after login
        else:
            flash('Incorrect username or password. Login failed.', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        mobile = request.form['mobile']
        address = request.form['address']
        dob = request.form['dob']

        if not all([username, password, first_name, last_name, mobile, address, dob]):
            flash('All fields are required.', 'error')
            return redirect(url_for('register'))

        save_user(username, password, first_name, last_name, mobile, address, dob)
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_query = request.form['user_query']
    chatbot_response = get_chatbot_response(user_query)
    return jsonify({'response': chatbot_response})

def get_chatbot_response(user_query):
    user_query = user_query.lower()
    for index, row in laws_dataset.iterrows():
        question = str(row['Questions']).lower()
        if user_query in question:
            return str(row['Answers'])
    return "I'm sorry, I couldn't find information on that topic."

@app.route('/tamper_detection', methods=['GET', 'POST'])
def tamper_detection():
    if request.method == 'POST':
        # Handle tamper detection logic here
        return 'Tamper detection logic goes here'
    return render_template('tampering.html')

if __name__ == '__main__':
    app.run(debug=True)
