import pandas as pd

# Read the CSV file into a DataFrame
set_df = pd.read_csv('set.csv')

# Preprocess the data (if needed)
# For example, remove duplicates and handle missing values

# Implement chatbot logic
def get_response(user_input):
    # Search for relevant information in the DataFrame based on user input
    matching_row = set_df[set_df['Questions'].str.contains(user_input, case=False)]
    
    # If a matching row is found, return the corresponding response
    if not matching_row.empty:
        return matching_row.iloc[0]['Answers']
    else:
        return "I'm sorry, I couldn't find information on that topic."

# Example usage
user_input = input("User: ")
response = get_response(user_input)
print("Bot:", response)
