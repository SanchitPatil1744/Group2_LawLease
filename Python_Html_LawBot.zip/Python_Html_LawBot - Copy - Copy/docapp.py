from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

credentials = {'RidvikThakur': 'ridvik2003',}
Link = "https://AWSservices.com/extract/confidential/jehagaherbacad/"

explanation_data = pd.read_csv('Explain.csv')

@app.route('/')
def index():
    return render_template('LawCV.html')

@app.route('/generate_output', methods=['POST'])
def generate_output():
    if 'image' not in request.files:
        return render_template('LawCV.html', error="No image selected")

    image = request.files['image']
    if image.filename == '':
        return render_template('LawCV.html', error="No image selected")

    document_type = request.form['document_type']
    explanation = get_explanation(document_type)
    return render_template('LawCV.html', explanation=explanation)



def get_explanation(document_type):
    # Find the row corresponding to the selected document type
    row = explanation_data[explanation_data['doc_type'] == document_type].iloc[0]

    # Extract explanation data from the row
    explanation = {
        'uses': row['uses'],
        'acts_use': row['acts_use'],
        'issuer_auth': row['issuer_auth'],
        'state_use': row['state_use'],
        'section_meaning': row['section_meaning']
    }

    return explanation

def verify(username,password,Link):
     if username in credentials and credentials[username] == password:
        return Link
     return False

# This code block will be executed when the script is run directly
if __name__ == '__main__':
    app.run(debug=True)
